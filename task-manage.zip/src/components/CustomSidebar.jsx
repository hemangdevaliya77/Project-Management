import React, { useState,useRef,useEffect } from "react";
import "./customcss/sidebar.css";

function CustomSidebar({ values }) {
  const [isOpen, setIsOpen] = useState(false);
  const [openDropdownIndex, setOpenDropdownIndex] = useState(null);

  const sidebarRef = useRef();

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);


  function toggleSidebar() {
    console.log("toggle",isOpen)

    setIsOpen(!isOpen);
  }

  const handleDropdownToggle = (index) => {
    setOpenDropdownIndex(openDropdownIndex === index ? null : index);
  };

  return (
    <div  ref={sidebarRef} style={{ width: 'max-content' }}> 
      <button onClick={toggleSidebar}>Toggle Sidebar</button>
      <ul className={`sidebar ${isOpen ? "open" : ""}`}>
        {values.map((item, index) => (
          <li key={index} className="main-dropdown">
            <div
              onClick={() => handleDropdownToggle(index)}
              style={{ display: "block", cursor: "pointer", padding: 5 }}
            >
              {Array.isArray(item.value) && <span className="icon">▼</span>}
              {item.label}
              
            </div>
            {item.image && (
              <img
                src={item.image}
                alt={`${item.label} icon`}
                className="sidebar-image"
              />
            )}
            {Array.isArray(item.value) && openDropdownIndex === index && (
              <ul className="sidebar-dropdown">
                {item.value.map((subItem, subIndex) => (
                  <li
                    key={subIndex}
                    style={{ paddingLeft: "20px", margin: "10px" }}
                    
                  >
                    
                    {subItem}
                      
                  </li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default CustomSidebar;
